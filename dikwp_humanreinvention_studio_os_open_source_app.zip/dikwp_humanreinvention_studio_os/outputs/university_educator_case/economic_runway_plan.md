# Economic Runway Plan

Current runway proxy: 0.7093
- Separate survival income from experimentation budget.
- Prefer small reversible tests over identity-sized bets.
- Stop experiments that increase debt, health risk, or family instability beyond the declared boundary.
