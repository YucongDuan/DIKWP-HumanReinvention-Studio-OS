# AI Dependency Stress Test

1. Complete one important task without the preferred model.
2. Export prompts, notes, evidence, and outputs to an open format.
3. Test a second provider or an offline workflow.
4. Identify the single point of failure.
5. Define the human-owned fallback and recovery time.
