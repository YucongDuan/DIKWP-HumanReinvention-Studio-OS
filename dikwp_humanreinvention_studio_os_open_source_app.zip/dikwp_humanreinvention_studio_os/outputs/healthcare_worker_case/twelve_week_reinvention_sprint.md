# 12-Week Human Reinvention Sprint

## Weeks 1-2 — Sense and unlearn
Map tasks, obsolete beliefs, evidence gaps, and runway.
## Weeks 3-4 — Reframe and fork roles
Create three role forks and interview real users.
## Weeks 5-6 — Build a reversible experiment
Use AI for speed while retaining human framing and responsibility.
## Weeks 7-8 — Produce proof
Publish or mentor-review an artifact with evidence and AI-use disclosure.
## Weeks 9-10 — Test portability
Export data, switch models, and run an AI-dependence stress test.
## Weeks 11-12 — Compound
Select one role fork, one network commitment, and one next experiment.
