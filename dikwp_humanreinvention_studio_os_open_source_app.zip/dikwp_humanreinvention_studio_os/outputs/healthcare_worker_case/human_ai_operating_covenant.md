# Human-AI Operating Covenant

- AI may expand options, but the human owns purpose and consequence.
- Delegation requires reversibility, logs, and a rollback path.
- AI use must be disclosed when it materially shapes a public or evaluated artifact.
- No fabricated credentials, hidden surveillance, or punitive ranking.
- Important memory and evidence must remain portable outside one platform.
