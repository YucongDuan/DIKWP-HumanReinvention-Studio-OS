# 30 / 90 / 365 Day Plan

## First 30 days
Protect runway, retire one low-value task, and define three role forks.
## By 90 days
Complete one real-user experiment and one proof-of-value artifact.
## By 365 days
Build a portable portfolio, trusted network, and at least two income or impact options.
