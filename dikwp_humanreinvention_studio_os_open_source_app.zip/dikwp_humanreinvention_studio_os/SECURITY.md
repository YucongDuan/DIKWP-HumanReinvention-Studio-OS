# Security Policy

The offline core intentionally has no network clients, browser automation, credential capture, hidden telemetry, or external actuation.

Report vulnerabilities privately to the project maintainer before public disclosure. Never include real personal data, secrets, medical records, employment records, or assessment results in an issue.
