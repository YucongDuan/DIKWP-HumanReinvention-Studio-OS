from __future__ import annotations

import csv
import json
from dataclasses import asdict
from pathlib import Path
from statistics import mean
from typing import Any, Dict, Iterable, List

from .models import AnalysisResult, ExperimentProfile, ReinventionProfile, RoleFork, TaskProfile

CAPABILITY_DEFAULTS = {
    "problem_framing": 0.5,
    "evidence_judgment": 0.5,
    "domain_depth": 0.5,
    "creativity": 0.5,
    "systems_thinking": 0.5,
    "relationship_trust": 0.5,
    "embodied_judgment": 0.3,
    "ethical_accountability": 0.6,
    "learning_velocity": 0.5,
    "ai_tool_literacy": 0.5,
    "public_value_design": 0.4,
    "self_reflection": 0.5,
}

RESOURCE_DEFAULTS = {
    "income_stability": 0.5,
    "savings_buffer": 0.3,
    "time_sovereignty": 0.4,
    "health_capacity": 0.6,
    "mentor_access": 0.3,
    "peer_network": 0.4,
    "institutional_access": 0.4,
    "portfolio_assets": 0.3,
    "model_diversity": 0.3,
    "data_portability": 0.4,
}

RISK_DEFAULTS = {
    "identity_lockin": 0.5,
    "status_dependency": 0.4,
    "credential_dependency": 0.5,
    "platform_dependency": 0.5,
    "decision_outsourcing": 0.4,
    "financial_fragility": 0.4,
    "attention_capture": 0.5,
    "social_isolation": 0.3,
    "burnout_pressure": 0.4,
    "learning_avoidance": 0.3,
}

BLOCK_TERMS = [
    "steal password", "capture credentials", "disable audit", "delete logs", "hidden surveillance",
    "secretly monitor", "manipulate people", "sabotage competitor", "insider trading",
    "market manipulation", "fake certificate", "fabricate credentials", "discriminate applicants",
    "automatic firing", "automatic hiring", "social credit", "covert persuasion",
]

REVIEW_TERMS = [
    "medical decision", "legal decision", "investment decision", "hire", "fire", "promotion",
    "salary", "credit", "insurance", "welfare eligibility", "mental health crisis",
]


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def safe_mean(values: Iterable[float], fallback: float = 0.5) -> float:
    vals = list(values)
    return mean(vals) if vals else fallback


def normalized_map(raw: Dict[str, Any] | None, defaults: Dict[str, float]) -> Dict[str, float]:
    raw = raw or {}
    return {k: clamp(raw.get(k, d)) for k, d in defaults.items()}


def load_case(path: str | Path) -> ReinventionProfile:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return ReinventionProfile(
        profile_id=data.get("profile_id", "reinvention-demo"),
        name=data.get("name", "Synthetic profile"),
        role=data.get("role", "knowledge worker"),
        domain=data.get("domain", "general"),
        mode=data.get("mode", "individual"),
        life_stage=data.get("life_stage", "mid-career"),
        weekly_reinvention_hours=float(data.get("weekly_reinvention_hours", 5)),
        economic_runway_months=float(data.get("economic_runway_months", 4)),
        time_horizon_months=int(data.get("time_horizon_months", 24)),
        goals=list(data.get("goals", [])),
        values=list(data.get("values", [])),
        constraints=list(data.get("constraints", [])),
        feedback_plan=data.get("feedback_plan", "biweekly review"),
        capabilities=normalized_map(data.get("capabilities"), CAPABILITY_DEFAULTS),
        resources=normalized_map(data.get("resources"), RESOURCE_DEFAULTS),
        risks=normalized_map(data.get("risks"), RISK_DEFAULTS),
        tasks=[TaskProfile(**x) for x in data.get("tasks", [])],
        role_forks=[RoleFork(**x) for x in data.get("role_forks", [])],
        experiments=[ExperimentProfile(**x) for x in data.get("experiments", [])],
        evidence_artifacts=list(data.get("evidence_artifacts", [])),
        notes=list(data.get("notes", [])),
    )


def route_task(task: TaskProfile) -> Dict[str, Any]:
    human_anchor = safe_mean([
        task.trust_need, task.relationship_need, task.embodied_need,
        task.creativity_need, task.evidence_need, task.consequence,
    ])
    commodity_pressure = safe_mean([task.automation_exposure, task.codifiability, 1 - task.value_chain_contribution])
    if task.consequence >= 0.78 or task.trust_need >= 0.82 or task.embodied_need >= 0.78:
        route = "human_owned"
        rationale = "High consequence, trust, accountability, or embodied judgement requires human ownership."
    elif commodity_pressure >= 0.72 and task.value_chain_contribution <= 0.42:
        route = "retire_or_reduce"
        rationale = "Highly codifiable and automated work with limited value-chain contribution should be reduced."
    elif task.automation_exposure >= 0.68 and task.reversibility >= 0.62 and task.consequence <= 0.48:
        route = "delegate_with_logs"
        rationale = "Routine and reversible work can be delegated while retaining logs and rollback."
    elif human_anchor >= 0.58 or task.value_chain_contribution >= 0.64:
        route = "augment_and_deepen"
        rationale = "AI can accelerate the task, while the person deepens judgement, evidence, trust, or creativity."
    else:
        route = "standardize_and_review"
        rationale = "Standardize the workflow and keep human review until evidence supports stronger delegation."
    renewal_value = clamp(
        0.24 * human_anchor
        + 0.20 * task.value_chain_contribution
        + 0.16 * task.creativity_need
        + 0.12 * task.reversibility
        + 0.14 * (1 - commodity_pressure)
        + 0.14 * task.evidence_need
    )
    return {
        "task_id": task.id,
        "task_name": task.name,
        "route": route,
        "rationale": rationale,
        "human_anchor": round(human_anchor, 3),
        "commodity_pressure": round(commodity_pressure, 3),
        "renewal_value": round(renewal_value, 3),
        "rollback_plan": "Preserve the prior human workflow, version outputs, and restore ownership if quality or trust falls.",
    }


def score_role_forks(items: List[RoleFork]) -> List[Dict[str, Any]]:
    rows = []
    for item in items:
        opportunity = clamp(
            0.17 * item.public_value
            + 0.14 * item.income_potential
            + 0.15 * item.proofability
            + 0.13 * item.trust_anchor
            + 0.14 * item.ai_leverage
            + 0.10 * item.portability
            + 0.10 * item.embodied_or_relational_anchor
            + 0.07 * (1 - item.learning_cost)
        )
        if opportunity >= 0.72 and item.proofability >= 0.6:
            route = "build_flagship_role_fork"
        elif opportunity >= 0.56:
            route = "run_market_and_user_experiment"
        else:
            route = "retain_as_option_not_commitment"
        rows.append({
            "role_fork_id": item.id,
            "title": item.title,
            "target_users": item.target_users,
            "opportunity_score": round(opportunity, 3),
            "route": route,
            "time_to_first_proof_weeks": item.time_to_first_proof_weeks,
            "proofability": round(item.proofability, 3),
            "public_value": round(item.public_value, 3),
            "ai_leverage": round(item.ai_leverage, 3),
        })
    return sorted(rows, key=lambda x: x["opportunity_score"], reverse=True)


def score_experiments(items: List[ExperimentProfile]) -> List[Dict[str, Any]]:
    rows = []
    for item in items:
        experiment_quality = clamp(
            0.22 * item.reversibility
            + 0.20 * item.evidence_strength_target
            + 0.18 * item.public_value
            + 0.15 * item.ai_leverage
            + 0.15 * min(1.0, item.real_user_count_target / 10)
            + 0.10 * (1 - item.risk)
        )
        route = "launch_now" if experiment_quality >= 0.68 else "refine_then_launch" if experiment_quality >= 0.5 else "redesign"
        rows.append({
            "experiment_id": item.id,
            "title": item.title,
            "hypothesis": item.hypothesis,
            "experiment_quality": round(experiment_quality, 3),
            "route": route,
            "duration_weeks": item.duration_weeks,
            "budget": item.budget,
            "real_user_count_target": item.real_user_count_target,
            "kill_condition": "Stop if harm, deception, privacy loss, or no useful user evidence appears within the time box.",
        })
    return sorted(rows, key=lambda x: x["experiment_quality"], reverse=True)


def purpose_score(profile: ReinventionProfile) -> float:
    completeness = safe_mean([
        min(1.0, len(profile.goals) / 3),
        min(1.0, len(profile.values) / 3),
        min(1.0, len(profile.constraints) / 3),
        min(1.0, profile.time_horizon_months / 24),
        1.0 if profile.feedback_plan.strip() else 0.0,
    ])
    return clamp(0.7 * completeness + 0.15 * profile.capabilities["self_reflection"] + 0.15 * profile.capabilities["ethical_accountability"])


def compute_metrics(profile: ReinventionProfile, task_rows: List[Dict[str, Any]], roles: List[Dict[str, Any]], experiments: List[Dict[str, Any]]) -> Dict[str, float]:
    c, r, k = profile.capabilities, profile.resources, profile.risks
    human_distinctive = safe_mean([
        c["problem_framing"], c["evidence_judgment"], c["domain_depth"], c["creativity"],
        c["systems_thinking"], c["relationship_trust"], c["embodied_judgment"], c["ethical_accountability"],
    ])
    proof_density = clamp(
        0.35 * min(1.0, len(profile.evidence_artifacts) / 5)
        + 0.25 * safe_mean([x["proofability"] for x in roles], 0.3)
        + 0.25 * safe_mean([x["experiment_quality"] for x in experiments], 0.3)
        + 0.15 * r["portfolio_assets"]
    )
    ai_leverage_quality = clamp(
        0.35 * c["ai_tool_literacy"]
        + 0.20 * c["problem_framing"]
        + 0.20 * c["evidence_judgment"]
        + 0.15 * r["model_diversity"]
        + 0.10 * r["data_portability"]
        - 0.20 * k["decision_outsourcing"]
        - 0.10 * k["platform_dependency"]
    )
    economic_runway = clamp(0.55 * min(1.0, profile.economic_runway_months / 12) + 0.25 * r["income_stability"] + 0.20 * r["savings_buffer"])
    network_trust = clamp(0.35 * c["relationship_trust"] + 0.25 * r["mentor_access"] + 0.25 * r["peer_network"] + 0.15 * r["institutional_access"])
    option_resilience = clamp(
        0.35 * min(1.0, len(profile.role_forks) / 3)
        + 0.25 * safe_mean([x.get("opportunity_score", 0.3) for x in roles], 0.3)
        + 0.20 * r["model_diversity"]
        + 0.20 * economic_runway
    )
    learning_velocity = clamp(0.55 * c["learning_velocity"] + 0.20 * c["self_reflection"] + 0.15 * min(1.0, profile.weekly_reinvention_hours / 10) + 0.10 * r["mentor_access"])
    public_value = clamp(0.55 * c["public_value_design"] + 0.25 * safe_mean([x.get("public_value", 0.4) for x in roles], 0.4) + 0.20 * c["ethical_accountability"])
    obsolescence = clamp(safe_mean([t.automation_exposure * (0.6 + 0.4 * t.codifiability) for t in profile.tasks], 0.5))
    identity_lockin = clamp(0.45 * k["identity_lockin"] + 0.25 * k["status_dependency"] + 0.20 * k["credential_dependency"] + 0.10 * k["learning_avoidance"])
    health_and_time = clamp(0.55 * r["health_capacity"] + 0.45 * r["time_sovereignty"])
    p_score = purpose_score(profile)
    semantic_closure = clamp(
        0.18 * c["problem_framing"] + 0.16 * c["evidence_judgment"] + 0.14 * c["systems_thinking"]
        + 0.14 * c["ethical_accountability"] + 0.14 * p_score + 0.10 * c["self_reflection"]
        + 0.07 * (1 - k["decision_outsourcing"]) + 0.07 * r["data_portability"]
    )
    reinvention_readiness = clamp(
        0.18 * human_distinctive + 0.15 * ai_leverage_quality + 0.13 * proof_density + 0.12 * option_resilience
        + 0.12 * learning_velocity + 0.10 * economic_runway + 0.08 * network_trust + 0.07 * health_and_time
        + 0.05 * p_score - 0.10 * identity_lockin
    )
    return {k: round(v, 4) for k, v in {
        "reinvention_readiness_index": reinvention_readiness,
        "human_distinctive_value_index": human_distinctive,
        "ai_leverage_quality": ai_leverage_quality,
        "proof_of_value_density": proof_density,
        "option_resilience": option_resilience,
        "learning_velocity": learning_velocity,
        "network_and_trust_capital": network_trust,
        "economic_runway": economic_runway,
        "health_and_time_capacity": health_and_time,
        "public_value_orientation": public_value,
        "obsolescence_exposure": obsolescence,
        "identity_lockin_risk": identity_lockin,
        "purpose_continuity_score": p_score,
        "semantic_closure_score": semantic_closure,
    }.items()}


def choose_route(metrics: Dict[str, float]) -> str:
    if metrics["economic_runway"] < 0.34 or metrics["health_and_time_capacity"] < 0.36:
        return "stabilize_runway_before_reinvention"
    if metrics["reinvention_readiness_index"] >= 0.70 and metrics["proof_of_value_density"] >= 0.58:
        return "scale_proven_new_role"
    if metrics["reinvention_readiness_index"] >= 0.52:
        return "launch_12_week_reinvention_sprint"
    return "guided_reinvention_foundation"


def build_unlearning_ledger(profile: ReinventionProfile, tasks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    items = [
        ("knowledge_scarcity", "My value comes mainly from possessing information others lack.", "Shift to judgement, evidence, responsibility, and proof."),
        ("output_volume", "More output is automatically more value.", "Measure user outcome, learning, trust, and reusable assets."),
        ("single_role_identity", "My current title is my durable identity.", "Build three role forks and test them through reversible projects."),
        ("ai_speed_competition", "I must beat AI at speed and volume.", "Use AI for speed; own framing, consequences, relationships, and responsibility."),
        ("credential_security", "Credentials alone will protect my economic position.", "Convert credentials into visible projects, trusted relationships, and verifiable outcomes."),
    ]
    retire_count = sum(1 for t in tasks if t["route"] == "retire_or_reduce")
    rows = []
    for idx, (key, belief, replacement) in enumerate(items, 1):
        rows.append({
            "belief_id": f"UNL-{idx:02d}",
            "belief_key": key,
            "legacy_belief": belief,
            "replacement_belief": replacement,
            "evidence_trigger": f"{retire_count} task(s) currently routed to retire_or_reduce." if idx == 1 else "Review with project and user evidence.",
            "status": "active_review",
        })
    return rows


def build_scenarios(metrics: Dict[str, float]) -> List[Dict[str, Any]]:
    scenarios = [
        ("agentic_acceleration", 0.84, "Longer workflows are delegated to AI agents."),
        ("knowledge_price_collapse", 0.88, "Generic explanation and first-draft knowledge become cheap."),
        ("access_stratification", 0.72, "Premium models, tools, and data become unevenly accessible."),
        ("physical_ai_diffusion", 0.60, "Robots and embodied AI expand into real-world services."),
        ("credential_repricing", 0.78, "Credentials lose signalling power without outcome evidence."),
        ("synthetic_relationship_expansion", 0.66, "Affective and persistent AI relationships become common."),
    ]
    rows = []
    base = metrics["reinvention_readiness_index"]
    for name, pressure, description in scenarios:
        readiness = clamp(base + 0.18 * metrics["option_resilience"] + 0.12 * metrics["ai_leverage_quality"] - 0.22 * pressure)
        rows.append({
            "scenario": name,
            "pressure": pressure,
            "readiness": round(readiness, 3),
            "description": description,
            "response": "Run a reversible experiment, preserve human ownership, and produce evidence." if readiness >= 0.5 else "Build runway, skills, and trusted support before scaling exposure.",
        })
    return rows


def build_action_tickets(profile: ReinventionProfile, metrics: Dict[str, float], tasks: List[Dict[str, Any]], roles: List[Dict[str, Any]], experiments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    tickets: List[Dict[str, Any]] = []
    def add(title: str, priority: str, action: str, owner: str, weeks: int, kill: str, recovery: str) -> None:
        tickets.append({
            "ticket_id": f"HRN-{len(tickets)+1:03d}", "title": title, "priority": priority,
            "owner": owner, "timebox_weeks": weeks, "action": action,
            "kill_condition": kill, "recovery": recovery,
        })
    if metrics["economic_runway"] < 0.5:
        add("Protect reinvention runway", "P0", "Create a minimum cash, time, and health buffer before a high-risk role shift.", "profile owner", 4, "Debt, health, or family risk rises materially.", "Reduce scope and return to a lower-cost experiment.")
    retiring = [x for x in tasks if x["route"] == "retire_or_reduce"]
    if retiring:
        add("Retire one commoditized task", "P1", f"Reduce or remove: {retiring[0]['task_name']}. Reinvest saved time in proof-producing work.", "profile owner", 2, "Service quality or safety degrades.", "Restore the prior workflow and redesign delegation.")
    if roles:
        top = roles[0]
        add("Test the top role fork", "P1", f"Build the first proof for '{top['title']}' with at least three real users or reviewers.", "profile owner + mentor", max(2, min(8, top["time_to_first_proof_weeks"])), "No user value, no evidence, or unacceptable ethical risk.", "Narrow the user and problem definition, then rerun.")
    if experiments:
        ex = experiments[0]
        add("Launch a reversible experiment", "P1", ex["title"], "profile owner", ex["duration_weeks"], ex["kill_condition"], "Archive evidence, extract learning, and redesign the hypothesis.")
    add("Publish a proof-of-value artifact", "P1", "Create one public or mentor-reviewed artifact showing the problem, evidence, human contribution, AI contribution, and outcome.", "profile owner", 3, "Artifact relies on fabricated results, hidden AI use, or no verifiable outcome.", "Disclose limitations, correct the record, and rebuild from evidence.")
    add("Form a human renewal circle", "P2", "Recruit one mentor, two peers, and one real user for a biweekly review rhythm.", "profile owner", 4, "The group becomes status theatre or punitive ranking.", "Reset to evidence, consent, and mutual learning.")
    add("Run the AI-dependence stress test", "P2", "Complete one key task without the preferred model, export data, and test a second tool or offline fallback.", "profile owner", 2, "Fallback exposes security, privacy, or quality failures.", "Stop migration and document the blocked dependency.")
    return tickets


def build_dikwp_ledger(profile: ReinventionProfile, metrics: Dict[str, float], route: str) -> Dict[str, Any]:
    return {
        "object": "human_reinvention_case",
        "D": {
            "profile": {"role": profile.role, "domain": profile.domain, "mode": profile.mode, "life_stage": profile.life_stage},
            "time_and_runway": {"weekly_hours": profile.weekly_reinvention_hours, "economic_runway_months": profile.economic_runway_months},
            "task_count": len(profile.tasks), "role_fork_count": len(profile.role_forks), "experiment_count": len(profile.experiments),
        },
        "I": {
            "route": route,
            "automation_and_identity": {"obsolescence_exposure": metrics["obsolescence_exposure"], "identity_lockin_risk": metrics["identity_lockin_risk"]},
            "option_and_proof": {"option_resilience": metrics["option_resilience"], "proof_density": metrics["proof_of_value_density"]},
        },
        "K": {
            "mechanism": "Sense -> Unlearn -> Reframe -> Co-design -> Experiment -> Prove -> Compound",
            "task_routes": ["retire_or_reduce", "delegate_with_logs", "augment_and_deepen", "human_owned", "standardize_and_review"],
        },
        "W": {
            "values": profile.values,
            "boundaries": ["no punitive ranking", "no fabricated credentials", "no covert monitoring", "no high-impact automated decisions"],
        },
        "P": {
            "goals": profile.goals, "constraints": profile.constraints, "time_horizon_months": profile.time_horizon_months,
            "feedback_plan": profile.feedback_plan,
        },
        "R": {
            "semantic_closure_score": metrics["semantic_closure_score"],
            "residuals": ["future labour demand is uncertain", "self-reported inputs require external proof", "role forks need real-user validation"],
            "kill_conditions": ["evidence is fabricated", "health or financial runway deteriorates", "AI use removes human accountability", "project causes unconsented harm"],
            "recovery": ["reduce scope", "restore prior workflow", "seek mentor review", "rerun with real user evidence"],
        },
    }


def analyze(profile: ReinventionProfile) -> AnalysisResult:
    task_rows = [route_task(x) for x in profile.tasks]
    role_rows = score_role_forks(profile.role_forks)
    experiment_rows = score_experiments(profile.experiments)
    metrics = compute_metrics(profile, task_rows, role_rows, experiment_rows)
    route = choose_route(metrics)
    return AnalysisResult(
        profile_id=profile.profile_id,
        route=route,
        metrics=metrics,
        task_revaluation=task_rows,
        role_fork_portfolio=role_rows,
        experiment_portfolio=experiment_rows,
        action_tickets=build_action_tickets(profile, metrics, task_rows, role_rows, experiment_rows),
        dikwp_ledger=build_dikwp_ledger(profile, metrics, route),
        unlearning_ledger=build_unlearning_ledger(profile, task_rows),
        scenario_matrix=build_scenarios(metrics),
    )


def guard(text: str) -> Dict[str, Any]:
    lowered = text.lower()
    blocked = [x for x in BLOCK_TERMS if x in lowered]
    review = [x for x in REVIEW_TERMS if x in lowered]
    if blocked:
        return {"decision": "block_and_redirect", "matched_terms": blocked, "safe_redirect": "Use the system for voluntary learning, reversible experiments, evidence building, and non-punitive transition planning."}
    if review:
        return {"decision": "qualified_human_review_required", "matched_terms": review, "safe_redirect": "Prepare evidence and questions, but keep the qualified human decision owner."}
    return {"decision": "allow_reinvention_planning", "matched_terms": [], "boundary": "No guarantee of employment, income, or future demand."}


def _write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = sorted({k for row in rows for k in row.keys()})
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader(); writer.writerows(rows)


def _write_md(path: Path, title: str, lines: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("# " + title + "\n\n" + "\n".join(lines) + "\n", encoding="utf-8")


def write_outputs(profile: ReinventionProfile, result: AnalysisResult, outdir: str | Path) -> Dict[str, Any]:
    out = Path(outdir); out.mkdir(parents=True, exist_ok=True)
    report = asdict(result)
    (out / "human_reinvention_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "dikwp_reinvention_ledger.json").write_text(json.dumps(result.dikwp_ledger, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "proof_of_value_ledger.json").write_text(json.dumps(profile.evidence_artifacts, ensure_ascii=False, indent=2), encoding="utf-8")
    _write_csv(out / "task_revaluation_matrix.csv", result.task_revaluation)
    _write_csv(out / "role_fork_portfolio.csv", result.role_fork_portfolio)
    _write_csv(out / "experiment_portfolio.csv", result.experiment_portfolio)
    _write_csv(out / "unlearning_ledger.csv", result.unlearning_ledger)
    _write_csv(out / "scenario_matrix.csv", result.scenario_matrix)
    _write_csv(out / "action_tickets.csv", result.action_tickets)
    weeks = [
        "## Weeks 1-2 — Sense and unlearn\nMap tasks, obsolete beliefs, evidence gaps, and runway.",
        "## Weeks 3-4 — Reframe and fork roles\nCreate three role forks and interview real users.",
        "## Weeks 5-6 — Build a reversible experiment\nUse AI for speed while retaining human framing and responsibility.",
        "## Weeks 7-8 — Produce proof\nPublish or mentor-review an artifact with evidence and AI-use disclosure.",
        "## Weeks 9-10 — Test portability\nExport data, switch models, and run an AI-dependence stress test.",
        "## Weeks 11-12 — Compound\nSelect one role fork, one network commitment, and one next experiment.",
    ]
    _write_md(out / "twelve_week_reinvention_sprint.md", "12-Week Human Reinvention Sprint", weeks)
    _write_md(out / "thirty_ninety_365_plan.md", "30 / 90 / 365 Day Plan", [
        "## First 30 days\nProtect runway, retire one low-value task, and define three role forks.",
        "## By 90 days\nComplete one real-user experiment and one proof-of-value artifact.",
        "## By 365 days\nBuild a portable portfolio, trusted network, and at least two income or impact options.",
    ])
    _write_md(out / "human_ai_operating_covenant.md", "Human-AI Operating Covenant", [
        "- AI may expand options, but the human owns purpose and consequence.",
        "- Delegation requires reversibility, logs, and a rollback path.",
        "- AI use must be disclosed when it materially shapes a public or evaluated artifact.",
        "- No fabricated credentials, hidden surveillance, or punitive ranking.",
        "- Important memory and evidence must remain portable outside one platform.",
    ])
    _write_md(out / "ai_dependency_stress_test.md", "AI Dependency Stress Test", [
        "1. Complete one important task without the preferred model.",
        "2. Export prompts, notes, evidence, and outputs to an open format.",
        "3. Test a second provider or an offline workflow.",
        "4. Identify the single point of failure.",
        "5. Define the human-owned fallback and recovery time.",
    ])
    _write_md(out / "network_rewiring_plan.md", "Human Network Rewiring Plan", [
        "- One mentor for judgement.", "- Two peers for reciprocal review.", "- Three real users for evidence.", "- One institutional bridge for scale.", "- One public contribution for legitimacy.",
    ])
    _write_md(out / "economic_runway_plan.md", "Economic Runway Plan", [
        f"Current runway proxy: {result.metrics['economic_runway']}",
        "- Separate survival income from experimentation budget.",
        "- Prefer small reversible tests over identity-sized bets.",
        "- Stop experiments that increase debt, health risk, or family instability beyond the declared boundary.",
    ])
    return {"outdir": str(out), "route": result.route, "metrics": result.metrics}


def analyze_file(case_path: str | Path, outdir: str | Path) -> Dict[str, Any]:
    profile = load_case(case_path)
    result = analyze(profile)
    write_outputs(profile, result, outdir)
    return {"profile_id": profile.profile_id, "route": result.route, "metrics": result.metrics, "output_dir": str(outdir)}
