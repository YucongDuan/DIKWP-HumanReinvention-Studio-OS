from __future__ import annotations

import argparse
import json

from .analyzer import analyze_file, guard
from .static_audit import write_audit


def main(argv=None) -> None:
    parser = argparse.ArgumentParser(prog="humanreinvention")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("analyze", help="Analyze a human reinvention case JSON.")
    p.add_argument("case")
    p.add_argument("--out", default="outputs/demo")

    p = sub.add_parser("guard", help="Check a proposed AI or transition use.")
    p.add_argument("text")

    p = sub.add_parser("static-audit", help="Audit the offline source tree.")
    p.add_argument("root")
    p.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")

    args = parser.parse_args(argv)
    if args.command == "analyze":
        print(json.dumps(analyze_file(args.case, args.out), ensure_ascii=False, indent=2))
    elif args.command == "guard":
        print(json.dumps(guard(args.text), ensure_ascii=False, indent=2))
    else:
        print(json.dumps(write_audit(args.root, args.out), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
