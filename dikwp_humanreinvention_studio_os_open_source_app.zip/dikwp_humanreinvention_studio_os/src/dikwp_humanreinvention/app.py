"""Optional Streamlit front end. Open index.html for the dependency-free studio."""

try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None

from .analyzer import analyze, load_case

if st:
    st.set_page_config(page_title="DIKWP HumanReinvention Studio OS", layout="wide")
    st.title("DIKWP HumanReinvention Studio OS")
    st.caption("Turn AI disruption into reversible experiments, proof, role options, and human value renewal.")
    uploaded = st.file_uploader("Upload a case JSON", type=["json"])
    if uploaded:
        import tempfile
        with tempfile.NamedTemporaryFile("wb", suffix=".json", delete=False) as handle:
            handle.write(uploaded.read()); path = handle.name
        result = analyze(load_case(path))
        cols = st.columns(4)
        cols[0].metric("Reinvention", result.metrics["reinvention_readiness_index"])
        cols[1].metric("Human Value", result.metrics["human_distinctive_value_index"])
        cols[2].metric("Proof Density", result.metrics["proof_of_value_density"])
        cols[3].metric("Obsolescence", result.metrics["obsolescence_exposure"])
        st.write(result.route)
        st.dataframe(result.task_revaluation)
        st.dataframe(result.action_tickets)
else:  # pragma: no cover
    print("Install streamlit for the optional app, or open index.html.")
