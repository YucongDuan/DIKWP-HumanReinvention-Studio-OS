from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

BANNED_TERMS = [
    "requests",
    "urllib.request",
    "http.client",
    "socket",
    "subprocess",
    "os.system",
    "eval(",
    "exec(",
    "selenium",
    "playwright",
    "paramiko",
    "keyring",
    "getpass",
    "pyautogui",
    "pynput",
    "browser_cookie3",
]


def audit(root: str | Path) -> Dict[str, Any]:
    root_path = Path(root)
    findings = []
    for path in root_path.rglob("*.py"):
        if path.name == "static_audit.py":
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for term in BANNED_TERMS:
            if term in text:
                findings.append({"file": str(path), "term": term})
    return {
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": (
            "Offline planning core only: no network clients, browser automation, credential capture, "
            "hidden telemetry, punitive ranking, labour decisions, financial execution, or external actuation."
        ),
    }


def write_audit(root: str | Path, outpath: str | Path) -> Dict[str, Any]:
    result = audit(root)
    destination = Path(outpath)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result
