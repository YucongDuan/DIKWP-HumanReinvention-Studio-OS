from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class TaskProfile:
    id: str
    name: str
    frequency: float = 0.5
    value_chain_contribution: float = 0.5
    automation_exposure: float = 0.5
    codifiability: float = 0.5
    consequence: float = 0.5
    evidence_need: float = 0.5
    trust_need: float = 0.5
    relationship_need: float = 0.5
    embodied_need: float = 0.2
    creativity_need: float = 0.5
    reversibility: float = 0.6


@dataclass
class RoleFork:
    id: str
    title: str
    target_users: str
    public_value: float = 0.5
    income_potential: float = 0.5
    learning_cost: float = 0.5
    proofability: float = 0.5
    trust_anchor: float = 0.5
    ai_leverage: float = 0.6
    portability: float = 0.5
    embodied_or_relational_anchor: float = 0.4
    time_to_first_proof_weeks: int = 6


@dataclass
class ExperimentProfile:
    id: str
    title: str
    hypothesis: str
    duration_weeks: int = 2
    budget: float = 0.0
    reversibility: float = 0.8
    evidence_strength_target: float = 0.5
    real_user_count_target: int = 3
    public_value: float = 0.5
    ai_leverage: float = 0.6
    risk: float = 0.2


@dataclass
class ReinventionProfile:
    profile_id: str
    name: str
    role: str
    domain: str
    mode: str
    life_stage: str
    weekly_reinvention_hours: float
    economic_runway_months: float
    time_horizon_months: int
    goals: List[str]
    values: List[str]
    constraints: List[str]
    feedback_plan: str
    capabilities: Dict[str, float] = field(default_factory=dict)
    resources: Dict[str, float] = field(default_factory=dict)
    risks: Dict[str, float] = field(default_factory=dict)
    tasks: List[TaskProfile] = field(default_factory=list)
    role_forks: List[RoleFork] = field(default_factory=list)
    experiments: List[ExperimentProfile] = field(default_factory=list)
    evidence_artifacts: List[Dict[str, Any]] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)


@dataclass
class AnalysisResult:
    profile_id: str
    route: str
    metrics: Dict[str, float]
    task_revaluation: List[Dict[str, Any]]
    role_fork_portfolio: List[Dict[str, Any]]
    experiment_portfolio: List[Dict[str, Any]]
    action_tickets: List[Dict[str, Any]]
    dikwp_ledger: Dict[str, Any]
    unlearning_ledger: List[Dict[str, Any]]
    scenario_matrix: List[Dict[str, Any]]
