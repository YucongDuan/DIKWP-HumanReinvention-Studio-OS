from pathlib import Path

from dikwp_humanreinvention.analyzer import analyze, guard, load_case, route_task
from dikwp_humanreinvention.models import TaskProfile
from dikwp_humanreinvention.static_audit import audit

ROOT = Path(__file__).resolve().parents[1]


def test_demo_analysis():
    profile = load_case(ROOT / "examples" / "sample_reinvention_case.json")
    result = analyze(profile)
    assert result.route in {
        "stabilize_runway_before_reinvention",
        "guided_reinvention_foundation",
        "launch_12_week_reinvention_sprint",
        "scale_proven_new_role",
    }
    assert result.metrics["reinvention_readiness_index"] > 0.4
    assert len(result.task_revaluation) == 5
    assert len(result.action_tickets) >= 4


def test_task_routing():
    task = TaskProfile(
        id="x",
        name="routine formatting",
        value_chain_contribution=0.1,
        automation_exposure=0.95,
        codifiability=0.95,
        consequence=0.1,
        evidence_need=0.2,
        trust_need=0.1,
        relationship_need=0.1,
        embodied_need=0.0,
        creativity_need=0.1,
        reversibility=0.95,
    )
    assert route_task(task)["route"] == "retire_or_reduce"


def test_guard():
    assert guard("build a three-role transition portfolio")["decision"] == "allow_reinvention_planning"
    assert guard("steal password and disable audit")["decision"] == "block_and_redirect"
    assert guard("automatic firing decision")["decision"] in {"block_and_redirect", "qualified_human_review_required"}


def test_static_audit():
    result = audit(ROOT / "src")
    assert result["pass"] is True
