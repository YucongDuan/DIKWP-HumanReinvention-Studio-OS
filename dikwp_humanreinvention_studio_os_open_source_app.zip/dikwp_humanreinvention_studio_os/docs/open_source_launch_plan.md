# Open-Source Launch Plan

## Repository name

`DIKWP-HumanReinvention-Studio-OS`

## First release

- Publish the standalone studio, schema, CLI, five synthetic scenarios, tests, governance boundary, and demo outputs.
- Add screenshots and a three-minute walkthrough.
- Invite educators, healthcare workers, public-service teams, founders, and career-development practitioners to submit non-sensitive scenarios.

## Community issues

Use issue templates for:

- metric critique;
- scenario contribution;
- accessibility;
- localisation;
- pilot evidence;
- governance concern.

## Value layer

Potential official services include local calibration, facilitator training, institutional pilots, signed review reports, and TrustPassport registration.
