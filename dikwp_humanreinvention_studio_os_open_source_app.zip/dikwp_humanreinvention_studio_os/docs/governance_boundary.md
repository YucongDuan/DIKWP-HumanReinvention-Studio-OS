# Governance Boundary

## Allowed

- voluntary learning and mentoring;
- task redesign;
- portfolio and experiment planning;
- non-punitive team development;
- AI literacy and portability testing;
- public-value project design.

## Prohibited

- automatic hiring, firing, promotion, compensation, admissions, or discipline;
- psychological diagnosis or fixed human-value scores;
- credit, insurance, welfare, immigration, or policing decisions;
- covert monitoring, credential capture, or manipulation;
- fabricated credentials or outcomes;
- market manipulation, insider trading, or unauthorised financial execution.

## Interpretation rule

Metrics are developmental proxies. They must be explained, contested, updated, and supported by real-world evidence.
