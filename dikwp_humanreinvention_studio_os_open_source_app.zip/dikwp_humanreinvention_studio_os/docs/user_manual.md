# User Manual

## Browser mode

1. Open `index.html`.
2. Select a synthetic scenario.
3. Adjust capability, resource, and risk sliders.
4. Review dashboard metrics.
5. Inspect task routes and role forks.
6. Choose a reversible experiment.
7. Export the local JSON snapshot.

## CLI mode

```bash
pip install -e .
humanreinvention analyze examples/sample_reinvention_case.json --out outputs/demo
```

## Reading the outputs

- Treat the route as a planning recommendation, not a verdict.
- Inspect the metrics separately; do not reduce the person to one score.
- Prioritise low-runway and health constraints before ambitious role changes.
- Validate role forks with real users.
- Retain residual uncertainty and update the case after each experiment.
