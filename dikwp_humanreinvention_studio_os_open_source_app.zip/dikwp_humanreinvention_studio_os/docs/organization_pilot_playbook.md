# Organisation Pilot Playbook

## Pilot objective

Redesign work without turning AI transformation into covert layoffs, surveillance, or punitive ranking.

## Phase 0 — Governance

Define worker participation, privacy, appeal, data limits, and prohibited decisions.

## Phase 1 — Task map

Map tasks, not job labels. Identify low-value repetitive work, judgement bottlenecks, trust work, and new AI-created problems.

## Phase 2 — Voluntary cohort

Select a small cohort and provide protected learning time, mentors, and reversible experiments.

## Phase 3 — Evidence

Measure service quality, employee learning, workload, errors, user outcomes, trust, and portability. Do not use a single opaque score.

## Phase 4 — Scale or stop

Scale only if human capability, service quality, and worker agency improve. Stop if the programme becomes surveillance, work intensification, or hidden displacement.
