# Experiment Portfolio Guide

## Experiment design

Every experiment should include:

- a falsifiable hypothesis;
- a two-to-six-week time box;
- a budget ceiling;
- real users or reviewers;
- an evidence target;
- a reversible delivery mechanism;
- a kill condition;
- a recovery plan.

## Portfolio balance

- One low-cost discovery experiment;
- one user-value experiment;
- one public proof artifact;
- one portability or model-switching test;
- optionally, one institutional pilot.

## Failure budget

Failure is acceptable when it is bounded, documented, reversible, and produces learning. Hidden harm, fabricated evidence, privacy loss, and unconsented high-impact action are not acceptable “experiments”.
