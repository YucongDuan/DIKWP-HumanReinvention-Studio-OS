# Role-Forking Playbook

A role fork is a testable future position, not a prediction.

## Required fields

- target users;
- problem owned;
- public value;
- income or support mechanism;
- proofability;
- trust anchor;
- AI leverage;
- portability;
- embodied or relational anchor;
- time to first proof.

## Three-fork rule

Maintain three types of forks:

1. **Adjacent fork** — close to current expertise and fastest to test.
2. **Bridge fork** — combines current domain with AI, governance, education, or public value.
3. **Frontier fork** — explores a new category that may not yet have a stable job title.

Do not make an identity-sized commitment until at least one fork has real-user evidence.
