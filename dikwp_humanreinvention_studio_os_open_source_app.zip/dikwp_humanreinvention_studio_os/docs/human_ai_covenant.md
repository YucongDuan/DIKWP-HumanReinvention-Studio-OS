# Human-AI Operating Covenant

1. The human owns purpose, consequences, and final responsibility.
2. AI may expand options but must not silently rewrite goals.
3. Delegated actions require reversibility, logs, and rollback.
4. Important evidence and memory must remain portable.
5. Material AI contribution to evaluated work should be disclosed.
6. No fabricated credentials, covert monitoring, or punitive ranking.
7. When consequence, uncertainty, or irreversibility rises, qualified human review rises with it.
