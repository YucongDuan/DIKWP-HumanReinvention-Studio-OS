# Mentor Manual

## Mentor role

A mentor does not approve a person’s “human value”. The mentor helps test assumptions, locate evidence, reduce identity risk, and improve experiment design.

## Review rhythm

Every two weeks review:

- one task to retire, delegate, deepen, or own;
- one new user interview or piece of evidence;
- one role fork;
- one experiment result;
- one AI-dependence or portability issue;
- health, time, and economic runway.

## Questions

- What changed outside the person’s control?
- What did the person learn from actual users?
- Which claimed advantage is still only narrative?
- Which human responsibility is under-owned?
- What should stop immediately?
- What is the smallest next reversible test?
