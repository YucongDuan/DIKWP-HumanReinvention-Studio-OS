# Human Reinvention Protocol

## Stage 1 — Sense

Map tasks, economic runway, attention, health, identity, platform dependence, relationships, and current evidence.

## Stage 2 — Unlearn

Identify beliefs that were rational in a knowledge-scarcity economy but may be harmful in an AI-abundance economy. Typical examples include “more output equals more value”, “my title is my identity”, and “credentials guarantee future relevance”.

## Stage 3 — Reframe

Translate the situation from “Will AI replace me?” into:

- Which tasks are becoming cheap?
- Which responsibilities are becoming more important?
- Which human relationships and real-world consequences remain under-owned?
- Which new problems exist because AI has arrived?

## Stage 4 — Co-design

Create at least three future role forks. A role fork is not a job-title fantasy. It specifies target users, public value, proof, trust anchor, AI leverage, portability, and time to first evidence.

## Stage 5 — Experiment

Run a small, reversible experiment with a time box, cost ceiling, evidence target, real users, kill condition, and recovery plan.

## Stage 6 — Prove

Produce an artifact that makes human contribution, AI contribution, evidence, limitations, and user outcome visible.

## Stage 7 — Compound

Turn one validated experiment into a repeatable service, role, curriculum, workflow, community, or public-value asset. Preserve at least two additional options.
