# Task Revaluation Method

## Dimensions

Each task is evaluated on:

- automation exposure;
- codifiability;
- value-chain contribution;
- consequence;
- evidence need;
- trust need;
- relationship need;
- embodied need;
- creativity need;
- reversibility.

## Routes

### Retire or reduce

Use when a task is highly codifiable, highly automated, and contributes little differentiated value.

### Delegate with logs

Use when a task is repetitive, reversible, lower consequence, and can be restored to the previous workflow.

### Standardize and review

Use when evidence is insufficient for full delegation. Define the process, collect failures, and keep human review.

### Augment and deepen

Use when AI can accelerate parts of the work but human judgement, evidence, creativity, relationships, or context determine quality.

### Human owned

Use when consequence, trust, responsibility, tacit judgement, physical-world presence, or irreversible effects are central.

## Non-goal

The matrix does not assign human worth. It redesigns work allocation around evidence, responsibility, and value.
