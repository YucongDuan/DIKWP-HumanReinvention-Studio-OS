# Architecture

## Runtime layers

```text
Profile Intake
  -> Task Revaluation Engine
  -> Role-Fork Engine
  -> Experiment Portfolio Engine
  -> DIKWP Semantic Ledger
  -> Metric and Route Engine
  -> Action Ticket Generator
  -> Report and Export Layer
```

## Offline-first design

The reference core uses only Python standard-library modules. The browser studio is a self-contained HTML file. It does not call an external model, collect telemetry, or transmit profile data.

## Main data objects

- `ReinventionProfile`
- `TaskProfile`
- `RoleFork`
- `ExperimentProfile`
- `AnalysisResult`

## Separation of proof

- **SemProof:** the profile and proposed transition are internally coherent.
- **RunProof:** the reference implementation generated the outputs.
- **ExtProof:** real users, employers, institutions, customers, or communities validate value.
- **Residual:** future labour demand, market timing, and individual outcomes remain uncertain.

## Integration direction

The system can later integrate with DIKWP HumanContinuity, HumanInnovation, HigherEd Horizon, ActiveMed Workforce, TaskRide, ProofLedger, TrustPassport, and PilotFactory. External connectors should remain optional and separated from the offline core.
