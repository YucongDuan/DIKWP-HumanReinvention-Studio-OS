# Proof-of-Value Protocol

Future value claims should be supported by artifacts rather than titles alone.

## Minimum proof pack

- problem statement;
- target user;
- prior condition;
- method;
- human contribution;
- AI contribution;
- evidence source;
- observed outcome;
- limitation;
- next experiment;
- external reviewer or user feedback.

## Proof density

Proof density increases when multiple artifacts demonstrate outcomes across different users, contexts, or institutions. It decreases when outputs are generic, unreviewed, unverifiable, or dependent on one closed platform.
