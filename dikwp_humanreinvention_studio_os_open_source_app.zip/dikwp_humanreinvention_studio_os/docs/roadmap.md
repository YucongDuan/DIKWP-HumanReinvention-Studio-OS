# Roadmap

## v1.1

- multilingual interface;
- richer organisation mode;
- evidence-artifact import;
- accessibility improvements;
- configurable local weights.

## v1.5

- optional ProofLedger integration;
- cohort comparison without punitive ranking;
- mentor workflow;
- local scenario authoring UI;
- portfolio export.

## v2.0

- official DIKWP HumanReinvention registry;
- signed pilot reports;
- sector packs for education, health, public service, SMEs, and research;
- long-term longitudinal evidence, with consent and portability.
