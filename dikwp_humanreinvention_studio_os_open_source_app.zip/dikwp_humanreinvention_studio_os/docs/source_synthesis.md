# Source Synthesis

The system is informed by four external anchors and the DIKWP research materials:

- ILO 2025 task-level GenAI exposure research: most affected jobs are expected to be transformed rather than simply eliminated, with human input remaining important.
- World Economic Forum Future of Jobs Report 2025: technological, economic, demographic, and green-transition forces are reshaping work and skills through 2030.
- UNESCO AI competency frameworks: human-centred, ethical, technical, pedagogical, and creative competencies are needed for teachers and students.
- OECD Digital Education Outlook 2026: outsourcing tasks to general-purpose GenAI can improve performance without real learning; intentional design and preserved human agency are essential.

DIKWP contributions include D/I/K/W/P semantic registration, purpose contracts, semantic compression, intent coupling, residual preservation, and kill/recovery conditions.
