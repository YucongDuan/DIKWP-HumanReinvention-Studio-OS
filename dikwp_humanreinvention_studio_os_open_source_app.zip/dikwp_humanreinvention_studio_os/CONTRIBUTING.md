# Contributing

Contributions are welcome when they improve transparency, portability, learning value, accessibility, or evidence quality.

## Required boundaries

- Do not add covert monitoring, credential capture, punitive scoring, employment decisions, or high-impact automated action.
- Use synthetic data in examples.
- Document metric assumptions and failure conditions.
- Add or update tests for every scoring or routing change.
- Preserve attribution in `NOTICE` and `CITATION.cff`.
