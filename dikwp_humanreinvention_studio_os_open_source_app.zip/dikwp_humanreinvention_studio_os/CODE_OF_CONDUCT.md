# Code of Conduct

Participants must respect human dignity, privacy, intellectual contribution, and the right to disagree. Harassment, discriminatory ranking, manipulation, credential theft, and fabricated evidence are not accepted.
