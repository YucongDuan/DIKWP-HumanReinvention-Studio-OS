from pathlib import Path

from dikwp_humanreinvention.analyzer import analyze_file

ROOT = Path(__file__).resolve().parent
for case in sorted((ROOT / "examples").glob("*.json")):
    out = ROOT / "outputs" / case.stem
    result = analyze_file(case, out)
    print(case.name, result["route"], result["metrics"]["reinvention_readiness_index"])
